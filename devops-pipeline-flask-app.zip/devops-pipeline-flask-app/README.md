# DevOps Pipeline for Flask App

A complete DevOps project using Flask, Docker, Jenkins, Kubernetes, and Monitoring tools.
